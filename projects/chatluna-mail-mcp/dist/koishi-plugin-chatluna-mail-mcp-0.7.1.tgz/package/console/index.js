// client/index.ts
import { defineComponent, h, onMounted, nextTick, reactive, ref, resolveComponent } from "vue";

// client/task-form.ts
function splitTime(time) {
  const [hour, minute] = time.split(":");
  return { hour, minute };
}
function daysInMonth(year, month) {
  return new Date(Date.UTC(year, month, 0)).getUTCDate();
}
function localParts(iso, timezone) {
  const parts = new Intl.DateTimeFormat("en-GB", { timeZone: timezone, year: "numeric", month: "2-digit", day: "2-digit", hour: "2-digit", minute: "2-digit", hourCycle: "h23" }).formatToParts(new Date(iso));
  const p = Object.fromEntries(parts.map((v) => [v.type, v.value]));
  return { year: p.year, month: p.month, day: p.day, hour: p.hour, minute: p.minute };
}
function scheduledInstant(date, time, timezone) {
  const { hour, minute } = splitTime(time), y = Number(date.year), m = Number(date.month), d = Number(date.day);
  if (d < 1 || d > daysInMonth(y, m)) throw new Error("\u8BF7\u9009\u62E9\u6709\u6548\u65E5\u671F");
  const target = Date.UTC(y, m - 1, d, Number(hour), Number(minute));
  let instant = target;
  for (let i = 0; i < 5; i++) {
    const p = localParts(new Date(instant).toISOString(), timezone);
    const shown = Date.UTC(Number(p.year), Number(p.month) - 1, Number(p.day), Number(p.hour), Number(p.minute));
    const delta = target - shown;
    if (!delta) return new Date(instant).toISOString();
    instant += delta;
  }
  throw new Error("\u6240\u9009\u65E5\u671F\u65F6\u95F4\u5728\u8BE5\u65F6\u533A\u4E0D\u5B58\u5728\uFF0C\u8BF7\u8C03\u6574\u65F6\u95F4\uFF08\u53EF\u80FD\u9047\u5230\u590F\u4EE4\u65F6\uFF09");
}
function variableDefinitions(rows) {
  const fields = {};
  for (const row of rows) {
    const name = row.name.trim();
    if (!/^[a-zA-Z0-9_-]{1,64}$/.test(name)) throw new Error("\u53D8\u91CF\u540D\u79F0\u53EA\u80FD\u4F7F\u7528\u5B57\u6BCD\u3001\u6570\u5B57\u3001\u6A2A\u7EBF\u6216\u4E0B\u5212\u7EBF");
    if (Object.prototype.hasOwnProperty.call(fields, name)) throw new Error("\u53D8\u91CF\u540D\u79F0\u91CD\u590D\uFF1A" + name);
    Object.defineProperty(fields, name, { value: { required: row.required, default: row.default }, enumerable: true });
  }
  return fields;
}

// client/index.ts
import { icons, send } from "@koishijs/client";
var freshTask = () => ({
  id: "",
  name: "",
  useDefaultModel: false,
  enabled: false,
  scheduleType: "daily",
  time: "09:00",
  timezone: "Asia/Shanghai",
  weekdays: [1],
  runAt: "",
  conversationId: "",
  preset: "",
  model: "",
  prompt: "\u6839\u636E\u4E3B\u63D2\u4EF6\u9884\u8BBE\u548C\u5F53\u524D\u804A\u5929\u4E0A\u4E0B\u6587\uFF0C\u5224\u65AD\u662F\u5426\u6709\u503C\u5F97\u4E3B\u52A8\u901A\u77E5\u7684\u65B0\u4E8B\u9879\u3002\u6CA1\u6709\u5FC5\u8981\u65F6\u4E0D\u53D1\u9001\uFF1B\u6709\u5FC5\u8981\u65F6\u751F\u6210\u7B80\u6D01\u90AE\u4EF6\u3002",
  to: [],
  templateId: "briefing",
  variables: {},
  historyLimit: 60,
  cooldownMinutes: 60,
  executionMode: "context",
  tools: [],
  workflowImages: false,
  toolFailurePolicy: "stop",
  retryOnFailure: false,
  contextMode: "recent",
  contextMaxAgeHours: 0,
  minNewMessages: 0,
  contextOverflow: "reject"
});
var freshTemplate = () => ({
  id: "",
  name: "",
  prompt: "\u6839\u636E\u5F53\u524D\u4E0A\u4E0B\u6587\u751F\u6210\u7B80\u6D01\u7684\u56FE\u6587\u901A\u77E5\uFF0C\u4E0D\u865A\u6784\u4E8B\u5B9E\u6216\u56FE\u7247\u3002",
  fields: {},
  layout: { accent: "#2563eb", background: "#ffffff", textColor: "#1f2937", width: 640, heading: true, footer: "" }
});
var css = `
.mail-viewport{height:100%;min-height:0;overflow-y:auto;overflow-x:hidden;scrollbar-gutter:stable;overscroll-behavior-y:contain;background:var(--k-page-bg,#f5f7fb);color:var(--k-text-normal,var(--fg1,#334155));--mail-panel:var(--k-card-bg,#fff);--mail-border:var(--k-color-divider,#e2e8f0);--mail-muted:var(--k-text-light,#64748b);--mail-strong:var(--k-text-dark,var(--fg1,#0f172a));--mail-accent:var(--k-color-primary,#5268eb);--mail-tint:var(--k-color-primary-fade,rgba(82,104,235,.09));--mail-hover:var(--k-hover-bg,#f1f5f9)}
.mail-viewport:focus-visible{outline:2px solid var(--mail-accent);outline-offset:-2px}
.mail-viewport::-webkit-scrollbar,.mail-admin .scroll::-webkit-scrollbar,.mail-admin pre::-webkit-scrollbar{width:10px;height:9px}
.mail-viewport::-webkit-scrollbar-thumb,.mail-admin .scroll::-webkit-scrollbar-thumb,.mail-admin pre::-webkit-scrollbar-thumb{background:var(--k-color-border,#94a3b8);border:2px solid var(--k-page-bg,#f5f7fb);border-radius:10px}
.mail-viewport::-webkit-scrollbar-thumb:hover{background:var(--mail-muted)}
.mail-admin{padding:28px 30px 36px;max-width:1320px;margin:0 auto;box-sizing:border-box;font-size:14px;line-height:1.55}
.mail-admin *{box-sizing:border-box}.mail-admin h2{margin:0;font-size:26px;font-weight:700;letter-spacing:.02em;color:var(--mail-strong)}.mail-admin h3{margin:26px 0 14px;font-size:17px;font-weight:650;color:var(--mail-strong)}.mail-admin p{line-height:1.75;margin:10px 0}.mail-admin .hero{display:flex;justify-content:space-between;align-items:center;gap:16px;margin-bottom:22px}.mail-admin .hero-title{display:flex;align-items:center;gap:15px}.mail-admin .hero-icon{display:flex;align-items:center;justify-content:center;width:52px;height:52px;border-radius:16px;background:var(--mail-tint);color:var(--mail-accent);flex-shrink:0}.mail-admin .hero-icon svg{width:28px;height:28px}.mail-admin .hero p{margin:4px 0 0}.mail-admin .version{border:1px solid var(--mail-border);border-radius:20px;padding:5px 12px;font-size:12px;color:var(--mail-muted);white-space:nowrap}
.mail-admin .stats{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px;margin-bottom:16px}.mail-admin .stat{background:var(--mail-panel);border:1px solid var(--mail-border);border-radius:14px;padding:16px 19px;display:flex;justify-content:space-between;align-items:center;gap:12px}.mail-admin .stat-label{font-size:12px;color:var(--mail-muted)}.mail-admin .stat-value{font-size:19px;font-weight:650;color:var(--mail-strong);margin-top:4px;overflow-wrap:anywhere}.mail-admin .stat-symbol{color:var(--mail-accent);width:28px;height:28px;flex-shrink:0}.mail-admin .recipient-info{color:var(--mail-muted);font-size:12px;overflow-wrap:anywhere;margin-bottom:18px}
.mail-admin .navigation{position:sticky;top:0;z-index:5;display:flex;align-items:center;gap:8px;justify-content:space-between;padding:10px;margin-bottom:22px;border:1px solid var(--mail-border);border-radius:12px;background:var(--mail-panel);box-shadow:0 4px 16px #00000008}.mail-admin .tabs,.mail-admin .nav-tools{display:flex;gap:5px;align-items:center;flex-wrap:wrap}.mail-admin .navigation .tab{border-color:transparent;background:transparent;color:var(--mail-muted);padding:9px 15px;white-space:nowrap}.mail-admin .navigation .tab.active{background:var(--mail-tint);color:var(--mail-accent);font-weight:650}.mail-admin .nav-tools button{font-size:12px;padding:8px 10px}.mail-admin .bar{display:flex;gap:9px;align-items:center;flex-wrap:wrap;margin:14px 0}
.mail-admin button{padding:8px 14px;min-height:36px;border-radius:8px;border:1px solid var(--mail-border);background:var(--mail-panel);color:var(--mail-strong);cursor:pointer;font:inherit;line-height:1.4;transition:background .15s,border-color .15s,box-shadow .15s}.mail-admin button:hover:not(:disabled){background:var(--mail-hover);border-color:var(--mail-accent)}.mail-admin button:focus-visible,.mail-admin summary:focus-visible{outline:2px solid var(--mail-accent);outline-offset:3px}.mail-admin button:disabled{opacity:.5;cursor:wait}.mail-admin .primary{background:var(--mail-accent);color:#fff;border-color:var(--mail-accent);box-shadow:0 2px 5px #00000010}.mail-admin .primary:hover:not(:disabled){background:var(--mail-accent);filter:brightness(1.08)}.mail-admin .danger{color:var(--k-color-danger,#dc5151)}
.mail-admin .card{padding:24px;border:1px solid var(--mail-border);border-radius:14px;margin-bottom:22px;background:var(--mail-panel);box-shadow:0 2px 10px #00000003;min-width:0}.mail-admin .card>h3:first-child{margin-top:0}.mail-admin .card>h3:not(:first-child){padding-top:22px;border-top:1px solid var(--mail-border)}.mail-admin .editor-heading{scroll-margin-top:90px;outline:none}
.mail-admin details{margin:20px 0;border-top:1px solid var(--mail-border);padding-top:8px}.mail-admin details.card{border:1px solid var(--mail-border);padding:12px 20px}.mail-admin summary{cursor:pointer;font-weight:600;padding:12px 0;color:var(--mail-strong)}.mail-admin details[open]>summary{margin-bottom:14px}.mail-admin .variable-card{border:1px solid var(--mail-border);border-radius:12px;padding:18px;display:grid;gap:12px;background:var(--mail-tint);min-width:0}.mail-admin .chip{font-family:var(--font-family-code,monospace);color:var(--mail-accent);background:var(--mail-panel);padding:6px 10px;font-size:12px}.mail-admin .inline{display:flex;gap:10px;align-items:end;min-width:0}.mail-admin .inline>*{flex:1;min-width:0}.mail-admin .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,250px),1fr));gap:20px}
.mail-admin label{display:flex;flex-direction:column;gap:8px;font-size:13px;min-width:0}.mail-admin label>span{font-weight:500;color:var(--mail-strong)}.mail-admin input,.mail-admin select,.mail-admin textarea{padding:10px 12px;border:1px solid var(--mail-border);border-radius:8px;background:var(--k-page-bg,var(--mail-panel));color:inherit;font:inherit;box-sizing:border-box;width:100%;min-width:0;transition:border-color .15s,box-shadow .15s}.mail-admin input:focus,.mail-admin select:focus,.mail-admin textarea:focus{outline:none;border-color:var(--mail-accent);box-shadow:0 0 0 3px var(--mail-tint)}.mail-admin input::placeholder,.mail-admin textarea::placeholder{color:var(--mail-muted);opacity:.8}.mail-admin input:disabled{opacity:.6}.mail-admin input[type=checkbox]{width:16px;height:16px;accent-color:var(--mail-accent);flex-shrink:0}.mail-admin input[type=color]{height:42px;padding:5px}.mail-admin textarea{min-height:120px;resize:vertical;line-height:1.7}.mail-admin select{min-height:42px}
.mail-admin table{width:100%;min-width:620px;border-collapse:separate;border-spacing:0;font-size:13px;background:var(--mail-panel)}.mail-admin td,.mail-admin th{padding:15px 16px;border-bottom:1px solid var(--mail-border);text-align:left;vertical-align:middle;overflow-wrap:anywhere}.mail-admin th{font-size:12px;font-weight:600;color:var(--mail-muted);background:var(--mail-hover)}.mail-admin tr{border:none}.mail-admin tbody tr:last-child td{border-bottom:none}.mail-admin tbody tr:hover{background:var(--mail-hover)}.mail-admin td .bar{margin:0;gap:6px}.mail-admin td button{padding:6px 9px;font-size:12px;min-height:31px}.mail-admin .scroll{max-width:100%;overflow-x:auto;overflow-y:hidden;border:1px solid var(--mail-border);border-radius:12px;margin-bottom:20px}.mail-admin .muted{color:var(--mail-muted);font-size:12px}
.mail-admin .notice{padding:13px 16px;border:1px solid transparent;border-radius:10px;background:var(--mail-tint);color:var(--mail-accent);white-space:pre-wrap;font-size:13px;line-height:1.7}.mail-admin .error{background:var(--k-color-danger-fade,rgba(220,81,81,.09));color:var(--k-color-danger,#dc5151)}.mail-admin pre{white-space:pre-wrap;overflow-wrap:anywhere;font-family:var(--font-family-code,monospace);font-size:12px;max-height:300px;overflow:auto;line-height:1.7}.mail-admin iframe{width:100%;height:420px;border:1px solid var(--mail-border);border-radius:10px;background:#fff}.mail-admin .wide{grid-column:1/-1}.mail-admin .footer{margin-top:26px;padding-top:16px;border-top:1px solid var(--mail-border)}
@media(max-width:1000px){.mail-admin .navigation{align-items:flex-start;flex-direction:column}.mail-admin .nav-tools{justify-content:flex-end;width:100%}.mail-admin .editor-heading{scroll-margin-top:135px}}
@media(max-width:600px){.mail-admin{padding:18px 14px 28px}.mail-admin .hero{align-items:flex-start}.mail-admin h2{font-size:22px}.mail-admin .hero-icon{width:42px;height:42px;border-radius:12px}.mail-admin .hero p{max-width:240px}.mail-admin .stats{gap:8px}.mail-admin .stat{padding:12px;display:block}.mail-admin .stat-value{font-size:16px}.mail-admin .stat-symbol{display:none}.mail-admin .card{padding:18px 15px}.mail-admin .navigation{gap:6px;padding:7px}.mail-admin .tabs{display:flex;flex-wrap:nowrap;overflow-x:auto;width:100%;padding-bottom:3px}.mail-admin .navigation .tab{padding:8px 10px;font-size:12px;flex-shrink:0}.mail-admin .grid{gap:16px}.mail-admin .version{padding:4px 8px}.mail-admin td,.mail-admin th{padding:12px}}
@media(prefers-reduced-motion:reduce){.mail-admin *{transition:none!important;scroll-behavior:auto!important}}
`;
var MailIcon = defineComponent({ name: "MailEnvelopeIcon", setup: () => () => h("svg", { viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 1.7, "stroke-linecap": "round", "stroke-linejoin": "round", "aria-hidden": "true" }, [
  h("rect", { x: 3, y: 5, width: 18, height: 14, rx: 3 }),
  h("path", { d: "m4 7 8 6 8-6" })
]) });
var clone = (value) => JSON.parse(JSON.stringify(value));
var dateText = (s) => s ? new Date(s).toLocaleString() : "\u2014";
var weekdays = ["\u5468\u4E00", "\u5468\u4E8C", "\u5468\u4E09", "\u5468\u56DB", "\u5468\u4E94", "\u5468\u516D", "\u5468\u65E5"];
var MailPage = defineComponent({
  setup() {
    const viewport = ref(null), taskEditor = ref(null), templateEditor = ref(null);
    const focusEditor = (target) => {
      void nextTick(() => {
        target.value?.scrollIntoView({ block: "start" });
        target.value?.focus({ preventScroll: true });
      });
    };
    const switchTab = (value) => {
      tab.value = value;
      notice.value = "";
      resultDetails.value = null;
      viewport.value?.scrollTo({ top: 0 });
    };
    const data = ref({ tasks: [], templates: [], assets: [], runs: [], deliveries: [], allowedRecipients: [] });
    const tab = ref("tasks"), busy = ref(false), notice = ref(""), error = ref(false), resultDetails = ref(null);
    const task = reactive(freshTask()), expectedHash = ref(""), taskExisting = ref(false);
    const toText = ref(""), variableText = ref("{}");
    const defaultModel = ref(""), modelHash = ref("");
    const workflowSettings = ref({}), workflowHash = ref("");
    const date = reactive(localParts(new Date(Date.now() + 864e5).toISOString(), "Asia/Shanghai"));
    const variableRows = ref([]);
    const selections = {};
    const previewValues = ref({});
    const template = reactive(freshTemplate()), expectedVersion = ref(0), templateExisting = ref(false);
    const preview = ref(null), previewDraft = ref("");
    const recordKind = ref("run"), recordStatus = ref(""), recordPage = ref(1), recordData = ref(null), cleanupPlan = ref(null);
    const formatError = (e) => typeof e === "string" ? e.split("\n")[0].replace(/^Error:\s*/, "") : e instanceof Error ? e.message : "\u64CD\u4F5C\u5931\u8D25";
    async function refresh() {
      data.value = await send("mail-admin/snapshot");
      defaultModel.value = data.value.modelSettings.defaultModel;
      modelHash.value = data.value.modelSettings.hash;
      const { hash, ...settings } = data.value.workflowSettings;
      workflowSettings.value = settings;
      workflowHash.value = hash;
    }
    async function action(fn) {
      if (busy.value) return;
      busy.value = true;
      notice.value = "";
      error.value = false;
      resultDetails.value = null;
      try {
        await fn();
        if (!notice.value) notice.value = "\u64CD\u4F5C\u5B8C\u6210";
      } catch (e) {
        error.value = true;
        notice.value = formatError(e);
      } finally {
        busy.value = false;
      }
    }
    onMounted(() => {
      busy.value = true;
      void refresh().catch((e) => {
        error.value = true;
        notice.value = formatError(e);
      }).finally(() => busy.value = false);
    });
    const button = (label, fn, cls = "", urgent = false) => h("button", { type: "button", class: cls, disabled: busy.value && !urgent, onClick: () => {
      if (urgent) void Promise.resolve().then(fn).catch((e) => {
        error.value = true;
        notice.value = formatError(e);
      });
      else void action(async () => {
        await fn();
      });
    } }, label);
    function input(label, value, update, type = "text", attrs = {}) {
      return h("label", [h("span", label), h("input", { type, value, "aria-label": label, ...attrs, onInput: (e) => update(e.target.value) })]);
    }
    const area = (label, value, update) => h("label", { class: "wide" }, [h("span", label), h("textarea", { "aria-label": label, value, onSelect: (e) => {
      const el = e.target;
      selections[label] = [el.selectionStart, el.selectionEnd];
    }, onInput: (e) => update(e.target.value) })]);
    const select = (label, value, items, update) => h("label", [h("span", label), h("select", { "aria-label": label, value, onChange: (e) => update(e.target.value) }, items.map(([id, name]) => h("option", { value: id }, name)))]);
    const check = (label, value, update) => h("label", { style: "display:flex;flex-direction:row;align-items:center;gap:8px" }, [h("input", { type: "checkbox", checked: value, onChange: (e) => update(e.target.checked) }), label]);
    function editTask(row) {
      Object.assign(task, freshTask(), row ? clone(row.task) : {});
      taskExisting.value = !!row;
      expectedHash.value = row?.hash ?? "";
      Object.assign(date, localParts(task.runAt || new Date(Date.now() + 864e5).toISOString(), task.timezone));
      if (task.scheduleType === "once" && task.runAt) task.time = date.hour + ":" + date.minute;
      toText.value = task.to.join(", ");
      variableText.value = JSON.stringify(task.variables, null, 2);
    }
    function editTemplate(value, copy = false) {
      const loaded = value ? clone(value) : freshTemplate();
      const { version, ...definition } = loaded;
      Object.assign(template, freshTemplate(), definition);
      if (copy) {
        template.id = "";
        template.name += "\uFF08\u526F\u672C\uFF09";
      }
      templateExisting.value = !!value && !copy;
      expectedVersion.value = copy ? 0 : version ?? 0;
      variableRows.value = Object.entries(template.fields).map(([name, v]) => ({ name, required: v.required, default: v.default }));
      previewValues.value = {};
    }
    async function saveTask() {
      const value = { ...clone(task), id: task.id || "mail-" + crypto.randomUUID().slice(0, 12), to: toText.value.split(/[,;，；\n]/).map((s) => s.trim()).filter(Boolean), variables: JSON.parse(variableText.value) };
      if (!value.name.trim()) throw new Error("\u8BF7\u586B\u5199\u4EFB\u52A1\u540D\u79F0");
      if (!value.conversationId) throw new Error("\u8BF7\u9009\u62E9\u4E0A\u4E0B\u6587\u4F1A\u8BDD\uFF0C\u6216\u5728\u9AD8\u7EA7\u8BBE\u7F6E\u4E2D\u586B\u5199\u4F1A\u8BDD ID");
      if (value.scheduleType === "once") value.runAt = scheduledInstant(date, value.time, value.timezone);
      await send("mail-admin/task-save", { task: value, expectedHash: expectedHash.value });
      await refresh();
      editTask(data.value.tasks.find((r) => r.task.id === value.id));
      notice.value = "\u4EFB\u52A1\u5DF2\u4FDD\u5B58\u3002\u53D1\u9001\u4ECD\u53D7\u63D2\u4EF6\u603B\u5F00\u5173\u548C\u6536\u4EF6\u4EBA\u767D\u540D\u5355\u9650\u5236\u3002";
    }
    async function saveTemplate() {
      const value = { ...clone(template), fields: variableDefinitions(variableRows.value) };
      const saved = await send("mail-admin/template-save", { template: value, expectedVersion: expectedVersion.value });
      await refresh();
      editTemplate(saved);
      notice.value = "\u6A21\u677F\u5DF2\u4FDD\u5B58\u4E3A\u7248\u672C " + saved.version + "\uFF0C\u5DF2\u6709\u8349\u7A3F\u4FDD\u6301\u539F\u7248\u672C\u3002";
    }
    async function evaluate(id) {
      const { jobId } = await send("mail-admin/evaluate", { id });
      let result;
      const until = Date.now() + Math.max(15e4, (data.value.workflowSettings?.timeoutSeconds ?? 300) * 1e3 + 3e4);
      while (Date.now() < until) {
        const job = await send("mail-admin/evaluation-result", { jobId });
        if (job.done) {
          result = job.result;
          break;
        }
        await new Promise((resolve) => setTimeout(resolve, 700));
      }
      if (!result) throw new Error("\u5224\u65AD\u4ECD\u5728\u540E\u53F0\u8FD0\u884C\uFF0C\u8BF7\u7A0D\u540E\u5728\u6267\u884C\u8BB0\u5F55\u67E5\u770B\u7ED3\u679C");
      if (result.draftId) {
        preview.value = await send("mail-admin/preview", { id: result.draftId });
        previewDraft.value = result.draftId;
      }
      resultDetails.value = result;
      notice.value = "\u5224\u65AD\u7ED3\u679C\uFF1A" + (result.decision?.shouldSend ? "\u5EFA\u8BAE\u53D1\u9001\uFF0C\u5DF2\u751F\u6210\u8349\u7A3F" : result.status === "skipped" ? "\u672C\u6B21\u4E0D\u53D1\u9001" : result.status) + "\n" + (result.decision?.reason ?? result.detail ?? result.errorCode ?? "") + (result.source?.model ? "\n\u4F7F\u7528\u6A21\u578B\uFF1A" + result.source.model : "");
      await refresh();
    }
    async function loadPreview(id) {
      preview.value = await send("mail-admin/preview", { id });
      previewDraft.value = id;
      switchTab("templates");
    }
    const table = (headers, rows) => h("div", { class: "scroll" }, [
      h("table", [h("thead", [h("tr", headers.map((v) => h("th", v)))]), h("tbody", rows.length ? rows.map((row) => h("tr", row.map((v) => h("td", v)))) : [h("tr", [h("td", { colspan: headers.length }, "\u6682\u65E0\u8BB0\u5F55")])])])
    ]);
    function insertVariable(label, value, update, name) {
      if (!/^[a-zA-Z0-9_-]{1,64}$/.test(name)) throw new Error("\u8BF7\u5148\u586B\u5199\u6709\u6548\u7684\u53D8\u91CF\u540D\u79F0");
      const [start, end] = selections[label] ?? [value.length, value.length], token = "{{" + name + "}}";
      update(value.slice(0, start) + token + value.slice(end));
      selections[label] = [start + token.length, start + token.length];
    }
    function modelOptions(current = "") {
      const models = (data.value.catalog?.models ?? []).map((m) => [m.id, m.platform + " / " + m.name]);
      if (current && !models.some(([id]) => id === current)) models.unshift([current, current + "\uFF08\u5F53\u524D\u672A\u6CE8\u518C\uFF09"]);
      return models;
    }
    function modelPanel() {
      return [
        h("h3", "\u90AE\u4EF6\u5224\u65AD\u6A21\u578B"),
        h("div", { class: "card" }, [
          h("p", "\u9009\u62E9\u5DF2\u5728 ChatLuna \u4E2D\u914D\u7F6E\u7684\u804A\u5929\u6A21\u578B\uFF0C\u4F5C\u4E3A\u90AE\u4EF6\u4EFB\u52A1\u7684\u9ED8\u8BA4\u5224\u65AD\u6A21\u578B\u3002\u6BCF\u6B21\u4EFB\u52A1\u53EA\u8C03\u7528\u6240\u9009\u7684\u4E00\u4E2A\u6A21\u578B\u3002"),
          select("\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B", defaultModel.value, [["", "\u5C1A\u672A\u8BBE\u7F6E"], ...modelOptions(defaultModel.value)], (v) => defaultModel.value = v),
          h("div", { class: "bar" }, [button("\u4FDD\u5B58\u6A21\u578B\u8BBE\u7F6E", async () => {
            await send("mail-admin/model-save", { settings: { defaultModel: defaultModel.value }, expectedHash: modelHash.value });
            await refresh();
            notice.value = "\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B\u5DF2\u4FDD\u5B58\uFF1B\u9009\u62E9\u201C\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B\u201D\u7684\u4EFB\u52A1\u4F1A\u5728\u4E0B\u6B21\u5224\u65AD\u65F6\u4F7F\u7528\u3002";
          }, "primary"), button("\u5237\u65B0\u6A21\u578B\u76EE\u5F55", refresh)]),
          h("p", { class: "notice" }, "Agent \u81EA\u4E3B\u914D\u7F6E\uFF1A" + (data.value.allowAgentManage ? "\u5DF2\u5F00\u542F" : "\u672A\u5F00\u542F") + "\u3002\u8BF7\u5728\u672C\u63D2\u4EF6\u914D\u7F6E\u4E2D\u8BBE\u7F6E allowAgentManage\uFF1B\u5F00\u542F\u540E Agent \u53EF\u521B\u5EFA\u6A21\u677F\u3001\u914D\u7F6E\u5E76\u542F\u505C\u4EFB\u52A1\u3002"),
          h("p", { class: "muted" }, "\u6A21\u578B\u63A5\u53E3\u5730\u5740\u3001API Key \u53CA\u4F9B\u5E94\u5546\u53C2\u6570\u5728 ChatLuna \u5BF9\u5E94\u6A21\u578B\u9002\u914D\u5668\u4E2D\u914D\u7F6E\u3002\u672C\u9875\u590D\u7528\u73B0\u6709\u914D\u7F6E\uFF0C\u4E0D\u4FDD\u5B58\u7B2C\u4E8C\u4EFD\u5BC6\u94A5\u3002\u8DDF\u968F\u4F1A\u8BDD\u6216\u6307\u5B9A\u6A21\u578B\u7684\u4EFB\u52A1\u4E0D\u53D7\u9ED8\u8BA4\u6A21\u578B\u53D8\u66F4\u5F71\u54CD\u3002"),
          ...(data.value.catalog?.warnings ?? []).map((w) => h("p", { class: "notice" }, w)),
          table(["\u5E73\u53F0", "\u804A\u5929\u6A21\u578B"], (data.value.catalog?.models ?? []).map((m) => [m.platform, m.name]))
        ])
      ];
    }
    function workflowPanel() {
      const settings = workflowSettings.value;
      return [
        h("h3", "\u53D7\u63A7\u5DE5\u5177\u5DE5\u4F5C\u6D41"),
        ...data.value.workflowLocks?.length ? [h("div", { class: "card" }, [
          h("h3", "\u5C1A\u672A\u786E\u8BA4\u5B8C\u6210\u7684\u6267\u884C"),
          h("p", { class: "muted" }, "\u8D85\u65F6\u540E\u5916\u90E8\u7ED8\u56FE\u53EF\u80FD\u4ECD\u5728\u8FD0\u884C\uFF0C\u5F53\u524D\u4EFB\u52A1\u4F1A\u963B\u6B62\u518D\u6B21\u6267\u884C\u3002\u91CD\u542F\u540E\u7559\u4E0B\u7684\u672A\u77E5\u72B6\u6001\u9700\u5148\u53BB MediaLuna \u68C0\u67E5\u7ED3\u679C\uFF0C\u518D\u786E\u8BA4\u91CA\u653E\uFF1B\u91CA\u653E\u4E0D\u4F1A\u53D6\u6D88\u5916\u90E8\u7ED8\u56FE\u3002"),
          table(["\u4EFB\u52A1", "\u72B6\u6001", "\u64CD\u4F5C"], data.value.workflowLocks.map((lock) => [lock.id, lock.active ? "\u5916\u90E8\u6B65\u9AA4\u5C1A\u672A\u7ED3\u675F" : lock.status, lock.status === "unknown" && !lock.active ? button("\u786E\u8BA4\u5DF2\u6838\u5BF9\u5916\u90E8\u7ED3\u679C", async () => {
            if (!window.confirm("\u5DF2\u6838\u5BF9 MediaLuna \u6216\u5176\u4ED6\u5916\u90E8\u5DE5\u5177\u7ED3\u679C\uFF1F\u786E\u8BA4\u540E\u5141\u8BB8\u4E0B\u4E00\u6B21\u91CD\u65B0\u6267\u884C\uFF0C\u53EF\u80FD\u518D\u6B21\u4EA7\u751F\u8D39\u7528\u3002")) return;
            await send("mail-admin/workflow-resolve", { taskId: lock.id, expectedHash: lock.hash, confirm: true });
            await refresh();
          }) : "\u7B49\u5F85\u5916\u90E8\u6B65\u9AA4\u7ED3\u675F"]))
        ])] : [],
        h("div", { class: "card" }, [
          h("p", "\u5DE5\u5177\u6A21\u5F0F\u590D\u7528 ChatLuna Agent\u3002\u5148\u5728\u8FD9\u91CC\u6388\u6743\u5DE5\u5177\u4E0E\u6267\u884C\u8EAB\u4EFD\uFF0C\u518D\u5728\u4EFB\u52A1\u4E2D\u9009\u62E9\u5177\u4F53\u5DE5\u5177\u3002\u4E00\u6B21\u4EFB\u52A1\u7531\u4E00\u4E2A\u6A21\u578B\u7F16\u6392\uFF1B\u53D1\u4FE1\u4ECD\u7EDF\u4E00\u7ECF\u8FC7\u90AE\u4EF6\u767D\u540D\u5355\u548C\u5E42\u7B49\u68C0\u67E5\u3002"),
          check("\u5141\u8BB8\u5DE5\u5177\u5DE5\u4F5C\u6D41", !!settings.enabled, (v) => settings.enabled = v),
          h("h3", "\u6267\u884C\u8EAB\u4EFD"),
          h("p", { class: "muted" }, "\u5FC5\u987B\u4F7F\u7528\u771F\u5B9E\u5B58\u5728\u4E14\u5728\u7EBF\u7684\u673A\u5668\u4EBA\uFF0C\u4EE5\u53CA\u6709\u6743\u4F7F\u7528\u76F8\u5E94\u5DE5\u5177\u7684\u7528\u6237\u3002\u6B64\u8EAB\u4EFD\u7528\u4E8E\u5DE5\u5177\u6388\u6743\u4E0E MediaLuna \u8BA1\u8D39\uFF0C\u4E0D\u4F1A\u5355\u72EC\u53D1\u9001\u804A\u5929\u56DE\u590D\u3002"),
          h("div", { class: "grid" }, [
            select("\u6267\u884C\u673A\u5668\u4EBA", settings.platform && settings.selfId ? settings.platform + ":" + settings.selfId : "", [["", "\u8BF7\u9009\u62E9\u5728\u7EBF\u673A\u5668\u4EBA"], ...(data.value.workflowBots ?? []).map((b) => [b.platform + ":" + b.selfId, b.platform + " / " + b.selfId + " \xB7 " + b.status])], (v) => {
              const bot = (data.value.workflowBots ?? []).find((b) => b.platform + ":" + b.selfId === v);
              settings.platform = bot?.platform ?? "";
              settings.selfId = bot?.selfId ?? "";
            }),
            input("\u6267\u884C\u7528\u6237\u7684\u5E73\u53F0\u8D26\u53F7", settings.userId ?? "", (v) => settings.userId = v, "text", { placeholder: "\u4F8B\u5982 QQ \u7528\u6237\u53F7\uFF0C\u975E\u673A\u5668\u4EBA\u8D26\u53F7" }),
            check("\u4EE5\u79C1\u804A\u8EAB\u4EFD\u6267\u884C", settings.isDirect !== false, (v) => settings.isDirect = v),
            ...!settings.isDirect ? [input("\u9891\u9053 ID", settings.channelId ?? "", (v) => settings.channelId = v), input("\u7FA4\u7EC4 ID", settings.guildId ?? "", (v) => settings.guildId = v)] : []
          ]),
          h("h3", "\u5141\u8BB8\u7684\u5916\u90E8\u5DE5\u5177"),
          h("p", { class: "muted" }, "\u53EA\u9009\u62E9\u8BFB\u53D6\u8D44\u6599\u3001\u641C\u7D22\u3001\u6B4C\u66F2\u5E93\u7B49\u6240\u9700\u5DE5\u5177\u3002\u90AE\u4EF6\u53D1\u9001\u3001\u4EFB\u52A1\u8C03\u5EA6\u548C\u59D4\u6D3E\u7C7B\u5DE5\u5177\u4E0D\u4F1A\u5217\u51FA\uFF1B\u7ED8\u56FE\u4F7F\u7528\u4E0B\u65B9\u4E13\u7528\u6865\u63A5\u3002\u5DE5\u5177\u672C\u8EAB\u7684 ChatLuna \u6388\u6743\u4ECD\u751F\u6548\u3002"),
          !(data.value.workflowTools ?? []).length ? h("p", { class: "notice" }, "\u672A\u53D1\u73B0\u53EF\u7528\u5DE5\u5177\uFF0C\u8BF7\u5148\u8FDE\u63A5\u641C\u7D22\u6216\u6B4C\u66F2\u5E93 MCP\uFF0C\u518D\u5237\u65B0\u672C\u9875\u3002") : null,
          h("div", { class: "grid" }, (data.value.workflowTools ?? []).map((tool) => h("div", { class: "variable-card" }, [
            check(tool.name, (settings.allowedTools ?? []).includes(tool.name), (v) => settings.allowedTools = v ? [...settings.allowedTools, tool.name] : settings.allowedTools.filter((n) => n !== tool.name)),
            h("p", { class: "muted" }, tool.description || "\u65E0\u63CF\u8FF0")
          ]))),
          h("h3", "MediaLuna \u56FE\u7247\u4EA4\u63A5"),
          h("p", { class: "muted" }, "\u5F00\u542F\u540E\uFF0C\u4E3B Agent \u53EF\u901A\u8FC7 import_mail_image \u5BFC\u5165\u5DF2\u5B8C\u6210\u7684\u7ED8\u56FE\u4EFB\u52A1\u3002\u5B9A\u65F6\u4EFB\u52A1\u8FD8\u53EF\u5F00\u542F\u81EA\u52A8\u914D\u56FE\uFF0C\u6BCF\u6B21\u6267\u884C\u6700\u591A\u63D0\u4EA4\u4E00\u6B21\u7ED8\u56FE\u8BF7\u6C42\uFF0C\u53EF\u80FD\u4EA7\u751F\u7ED8\u56FE\u8D39\u7528\u3002\u7ED8\u56FE\u63D0\u793A\u8BCD\u7531\u6A21\u578B\u6839\u636E\u90AE\u4EF6\u5185\u5BB9\u81EA\u52A8\u751F\u6210\uFF0C\u7BA1\u7406\u5458\u53EA\u9650\u5B9A\u53EF\u7528\u6E20\u9053\u3002\u76EE\u524D\u4EC5\u63A5\u672C\u5730 PNG/JPEG \u7F13\u5B58\u3002"),
          h("div", { class: "grid" }, [
            check("\u5141\u8BB8\u5BFC\u5165 MediaLuna \u56FE\u7247", !!settings.mediaImportEnabled, (v) => settings.mediaImportEnabled = v),
            input("\u56FE\u7247\u6240\u5C5E\u7528\u6237\u7F16\u53F7\uFF08Koishi user.id\uFF09", settings.mediaOwnerId ?? "", (v) => settings.mediaOwnerId = v.trim() === "" ? null : Number(v), "number", { min: 0 })
          ]),
          h("p", { class: "muted" }, "\u6B64\u7F16\u53F7\u662F Koishi \u7528\u6237\u8868\u4E2D\u7684\u5185\u90E8\u6570\u5B57 ID\uFF0C\u4E0D\u662F QQ \u53F7\uFF1B0 \u662F\u5408\u6CD5\u503C\uFF0C\u7559\u7A7A\u8868\u793A\u672A\u914D\u7F6E\u3002\u81EA\u52A8\u7ED8\u56FE\u65F6\u5FC5\u987B\u4E0E\u4E0A\u65B9\u6267\u884C\u7528\u6237\u5BF9\u5E94\u3002\u6A21\u578B\u53EF\u4F7F\u7528 presetName \u6307\u5B9A\u5DF2\u6709 MediaLuna \u9884\u8BBE\u3002"),
          h("div", { class: "bar" }, (data.value.mediaChannels ?? []).map((c) => check("\u5141\u8BB8\u7ED8\u56FE\u6E20\u9053 " + c.name, (settings.mediaChannels ?? []).includes(c.name), (v) => settings.mediaChannels = v ? [...settings.mediaChannels, c.name] : settings.mediaChannels.filter((n) => n !== c.name)))),
          !(data.value.mediaChannels ?? []).length ? h("p", { class: "muted" }, "\u672A\u53D1\u73B0\u5DF2\u542F\u7528\u7684 MediaLuna \u6E20\u9053\uFF0C\u5F53\u524D\u4E0D\u80FD\u81EA\u52A8\u914D\u56FE\u3002") : null,
          h("details", [h("summary", "\u6267\u884C\u9884\u7B97"), h("div", { class: "grid" }, [
            input("\u6700\u591A Agent \u6B65\u6570", settings.maxSteps ?? 10, (v) => settings.maxSteps = Number(v), "number", { min: 1, max: 24 }),
            input("\u6700\u591A\u5DE5\u5177\u8C03\u7528", settings.maxToolCalls ?? 16, (v) => settings.maxToolCalls = Number(v), "number", { min: 1, max: 40 }),
            input("\u5DE5\u5177\u5DE5\u4F5C\u6D41\u603B\u8D85\u65F6\uFF08\u79D2\uFF09", settings.timeoutSeconds ?? 300, (v) => settings.timeoutSeconds = Number(v), "number", { min: 10, max: 900 }),
            input("\u5355\u6B21\u5DE5\u5177\u7ED3\u679C\u5B57\u7B26\u4E0A\u9650", settings.maxToolResultChars ?? 16e3, (v) => settings.maxToolResultChars = Number(v), "number", { min: 500, max: 6e4 })
          ])]),
          h("div", { class: "bar" }, [button("\u4FDD\u5B58\u5DE5\u4F5C\u6D41\u8BBE\u7F6E", async () => {
            await send("mail-admin/workflow-save", { settings: clone(settings), expectedHash: workflowHash.value });
            await refresh();
            notice.value = "\u5DE5\u4F5C\u6D41\u8BBE\u7F6E\u5DF2\u4FDD\u5B58\uFF1B\u7B56\u7565\u53D8\u52A8\u4F1A\u963B\u6B62\u5C1A\u672A\u5B8C\u6210\u7684\u65E7\u6267\u884C\u7EE7\u7EED\u8C03\u7528\u5DE5\u5177\u3002";
          }, "primary")])
        ])
      ];
    }
    function timePicker() {
      const p = splitTime(task.time), options = (n) => Array.from({ length: n }, (_, i) => [String(i).padStart(2, "0"), String(i).padStart(2, "0")]);
      return h("div", { class: "inline" }, [
        select("\u5C0F\u65F6", p.hour, options(24), (v) => task.time = v + ":" + p.minute),
        select("\u5206\u949F", p.minute, options(60), (v) => task.time = p.hour + ":" + v)
      ]);
    }
    function taskPanel() {
      const catalog = data.value.catalog ?? { conversations: [], presets: [], warnings: [] };
      const convOptions = catalog.conversations.map((c) => [c.id, (c.title || "\u672A\u547D\u540D\u4F1A\u8BDD") + " \xB7 " + c.id]);
      if (task.conversationId && !convOptions.some(([id]) => id === task.conversationId)) convOptions.unshift([task.conversationId, task.conversationId + "\uFF08\u4E0D\u5728\u6700\u8FD1\u5217\u8868\u4E2D\uFF09"]);
      const templateFields = Object.entries(data.value.templates.find((t) => t.id === task.templateId)?.fields ?? {});
      const vars = () => {
        try {
          return JSON.parse(variableText.value);
        } catch {
          return {};
        }
      };
      const modelValue = task.model || (task.useDefaultModel ? "__default" : "__conversation");
      const presets = [["", "\u8DDF\u968F\u4F1A\u8BDD\u9884\u8BBE"], ...catalog.presets.map((p) => [p, p])];
      if (task.preset && !presets.some(([id]) => id === task.preset)) presets.push([task.preset, task.preset + "\uFF08\u5F53\u524D\u672A\u6CE8\u518C\uFF09"]);
      return [
        h("div", { class: "bar" }, [button("\uFF0B \u65B0\u5EFA\u4EFB\u52A1", () => {
          editTask();
          focusEditor(taskEditor);
        }, "primary")]),
        table(["\u4EFB\u52A1", "\u8BA1\u5212", "\u4E0B\u6B21\u6267\u884C\uFF08\u672C\u673A\u663E\u793A\u65F6\u533A\uFF09", "\u72B6\u6001", "\u64CD\u4F5C"], data.value.tasks.map((r) => [
          r.task.name || r.task.id,
          r.task.scheduleType === "once" ? dateText(r.task.runAt) : r.task.time + " / " + r.task.timezone + (r.task.scheduleType === "weekly" ? " / " + r.task.weekdays.map((n) => weekdays[n - 1]).join("\u3001") : ""),
          r.nextRunAt ? dateText(r.nextRunAt) : "\u65E0\u540E\u7EED\u8BA1\u5212",
          !r.task.enabled ? "\u4EFB\u52A1\u505C\u7528" : r.blockedBy ? "\u53D7\u5168\u5C40\u5F00\u5173\u963B\u6B62" : "\u5DF2\u542F\u7528",
          h("div", { class: "bar" }, [
            button("\u7F16\u8F91", () => {
              editTask(r);
              focusEditor(taskEditor);
            }),
            button(r.task.enabled ? "\u505C\u7528" : "\u542F\u7528", async () => {
              await send("mail-admin/task-toggle", { id: r.task.id, enabled: !r.task.enabled, expectedHash: r.hash });
              await refresh();
            }),
            button(r.task.executionMode === "tools" ? "\u8BD5\u8FD0\u884C\u5DE5\u5177" : "\u8BD5\u5224\u65AD", () => evaluate(r.task.id)),
            button("\u4E0A\u4E0B\u6587\u8BCA\u65AD", async () => {
              const report = await send("mail-admin/diagnose", { id: r.task.id });
              resultDetails.value = report;
              notice.value = "\u4E0A\u4E0B\u6587\u68C0\u67E5\u5B8C\u6210\uFF1A" + report.historyCount + " \u6761\u6D88\u606F \xB7 \u6A21\u578B " + report.model + "\n" + (report.skipReason ?? "\u53EF\u4EE5\u8FDB\u884C\u6A21\u578B\u5224\u65AD\uFF0C\u672C\u6B21\u68C0\u67E5\u672A\u8C03\u7528\u6A21\u578B\u3002");
            }),
            button("\u5F52\u6863", async () => {
              if (!window.confirm("\u5F52\u6863\u4EFB\u52A1 " + (r.task.name || r.task.id) + "\uFF1F\u6267\u884C\u8BB0\u5F55\u4ECD\u4FDD\u7559\u3002")) return;
              await send("mail-admin/task-archive", { id: r.task.id, expectedHash: r.hash });
              await refresh();
            }, "danger")
          ])
        ])),
        h("h3", { class: "editor-heading", ref: taskEditor, tabindex: -1 }, taskExisting.value ? "\u7F16\u8F91\u4EFB\u52A1" : "\u65B0\u5EFA\u4EFB\u52A1"),
        h("div", { class: "card" }, [
          h("h3", "1. \u53D1\u7ED9\u8C01"),
          h("div", { class: "grid" }, [
            input("\u4EFB\u52A1\u540D\u79F0", task.name, (v) => task.name = v, "text", { placeholder: "\u4F8B\u5982 \u6BCF\u65E5\u4E8B\u9879\u63D0\u9192" }),
            input("\u6536\u4EF6\u4EBA", toText.value, (v) => toText.value = v, "text", { placeholder: "\u53EF\u586B\u5199\u591A\u4E2A\u90AE\u7BB1\uFF0C\u7528\u9017\u53F7\u5206\u9694" }),
            select("\u90AE\u4EF6\u6A21\u677F", task.templateId, data.value.templates.map((t) => [t.id, t.name]), (v) => task.templateId = v)
          ]),
          h("h3", "2. \u5224\u65AD\u4F9D\u636E"),
          h("div", { class: "grid" }, [
            select("\u4E0A\u4E0B\u6587\u4F1A\u8BDD", task.conversationId, [["", "\u8BF7\u9009\u62E9\u4F1A\u8BDD\uFF08\u6700\u8FD1 100 \u4E2A\u6D3B\u8DC3\u4F1A\u8BDD\uFF09"], ...convOptions], (v) => task.conversationId = v),
            select("\u5224\u65AD\u6A21\u578B", modelValue, [["__conversation", "\u8DDF\u968F\u4F1A\u8BDD\u6A21\u578B"], ["__default", "\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B" + (data.value.modelSettings?.defaultModel ? " \xB7 " + data.value.modelSettings.defaultModel : "\uFF08\u5C1A\u672A\u8BBE\u7F6E\uFF09")], ...modelOptions(task.model)], (v) => {
              task.useDefaultModel = v === "__default";
              task.model = ["__default", "__conversation"].includes(v) ? "" : v;
            })
          ]),
          h("div", { class: "grid" }, [
            select("\u6267\u884C\u65B9\u5F0F", task.executionMode, [["context", "\u53EA\u8BFB\u4E0A\u4E0B\u6587\u5224\u65AD"], ["tools", "\u5DE5\u5177\u5DE5\u4F5C\u6D41\uFF08\u641C\u7D22\uFF0F\u6B4C\u66F2\u5E93\uFF0F\u914D\u56FE\uFF09"]], (v) => task.executionMode = v)
          ]),
          ...task.executionMode === "tools" ? [
            h("p", { class: "notice" }, "\u8BD5\u8FD0\u884C\u4F1A\u771F\u5B9E\u8C03\u7528\u6240\u9009\u5DE5\u5177\uFF0C\u53EF\u80FD\u4EA7\u751F\u6A21\u578B\u6216\u7ED8\u56FE\u8D39\u7528\uFF0C\u4F46\u4E0D\u4F1A\u81EA\u52A8\u53D1\u9001\u90AE\u4EF6\u3002\u6700\u591A " + (data.value.workflowSettings?.maxSteps ?? 10) + " \u6B65\uFF0F" + (data.value.workflowSettings?.maxToolCalls ?? 16) + " \u6B21\u5DE5\u5177\uFF0F" + (data.value.workflowSettings?.timeoutSeconds ?? 300) + " \u79D2\u3002"),
            !data.value.workflowSettings?.enabled ? h("p", { class: "error" }, "\u8BF7\u5148\u5728\u201C\u5DE5\u4F5C\u6D41\u201D\u9875\u914D\u7F6E\u6267\u884C\u8EAB\u4EFD\u5E76\u5F00\u542F\u5DE5\u5177\u5DE5\u4F5C\u6D41\u3002") : null,
            h("div", { class: "grid" }, (data.value.workflowSettings?.allowedTools ?? []).map((name) => check(name, task.tools.includes(name), (v) => task.tools = v ? [...task.tools, name] : task.tools.filter((n) => n !== name)))),
            h("div", { class: "grid" }, [
              check("\u5141\u8BB8\u81EA\u52A8\u914D\u56FE\uFF08\u6BCF\u6B21\u6700\u591A\u4E00\u6B21\u7ED8\u56FE\u8BF7\u6C42\uFF09", task.workflowImages, (v) => task.workflowImages = v),
              select("\u5DE5\u5177\u6216\u7ED8\u56FE\u5931\u8D25\u65F6", task.toolFailurePolicy, [["stop", "\u505C\u6B62\u672C\u6B21\u4EFB\u52A1\uFF08\u9ED8\u8BA4\uFF09"], ["continue", "\u5141\u8BB8\u8DF3\u8FC7\u5931\u8D25\u8D44\u6599\u6216\u914D\u56FE\u7EE7\u7EED\u5224\u65AD"]], (v) => task.toolFailurePolicy = v)
            ])
          ] : [],
          !catalog.conversations.length ? h("p", { class: "muted" }, "\u6682\u672A\u53D6\u5F97\u4F1A\u8BDD\u5217\u8868\uFF0C\u53EF\u5237\u65B0\u6216\u5C55\u5F00\u9AD8\u7EA7\u8BBE\u7F6E\u586B\u5199\u4F1A\u8BDD ID\u3002") : null,
          task.useDefaultModel && !data.value.modelSettings?.defaultModel ? h("p", { class: "error" }, "\u8BF7\u5148\u5230\u201C\u6A21\u578B\u8BBE\u7F6E\u201D\u9009\u62E9\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B\u3002") : null,
          h("h3", "3. \u4F55\u65F6\u5224\u65AD"),
          h("div", { class: "grid" }, [
            select("\u6267\u884C\u9891\u7387", task.scheduleType, [["daily", "\u6BCF\u5929"], ["weekly", "\u6BCF\u5468"], ["once", "\u4EC5\u4E00\u6B21"]], (v) => task.scheduleType = v),
            select("\u6267\u884C\u65F6\u533A", task.timezone, [["Asia/Shanghai", "\u5317\u4EAC\u65F6\u95F4\uFF08UTC+8\uFF09"], ["Asia/Hong_Kong", "\u9999\u6E2F\u65F6\u95F4\uFF08UTC+8\uFF09"], ["Asia/Tokyo", "\u4E1C\u4EAC\u65F6\u95F4\uFF08UTC+9\uFF09"], ["UTC", "\u4E16\u754C\u534F\u8C03\u65F6\uFF08UTC\uFF09"], ["America/New_York", "\u7EBD\u7EA6\u65F6\u95F4\uFF08\u81EA\u52A8\u590F\u4EE4\u65F6\uFF09"], ...!["Asia/Shanghai", "Asia/Hong_Kong", "Asia/Tokyo", "UTC", "America/New_York"].includes(task.timezone) ? [[task.timezone, task.timezone]] : []], (v) => task.timezone = v),
            ...task.scheduleType === "once" ? [h("div", { class: "inline wide" }, [
              select("\u5E74", date.year, Array.from(/* @__PURE__ */ new Set([Number(date.year), ...Array.from({ length: 11 }, (_, i) => (/* @__PURE__ */ new Date()).getFullYear() + i)])).sort().map((y) => [String(y), String(y) + "\u5E74"]), (v) => {
                date.year = v;
                date.day = String(Math.min(Number(date.day), daysInMonth(Number(v), Number(date.month)))).padStart(2, "0");
              }),
              select("\u6708", date.month, Array.from({ length: 12 }, (_, i) => [String(i + 1).padStart(2, "0"), i + 1 + "\u6708"]), (v) => {
                date.month = v;
                date.day = String(Math.min(Number(date.day), daysInMonth(Number(date.year), Number(v)))).padStart(2, "0");
              }),
              select("\u65E5", date.day, Array.from({ length: daysInMonth(Number(date.year), Number(date.month)) }, (_, i) => [String(i + 1).padStart(2, "0"), i + 1 + "\u65E5"]), (v) => date.day = v)
            ])] : [],
            timePicker(),
            ...task.scheduleType === "weekly" ? [h("div", { class: "bar wide" }, weekdays.map((name, i) => check(name, task.weekdays.includes(i + 1), (checked) => {
              task.weekdays = checked ? [...task.weekdays, i + 1].sort() : task.weekdays.filter((n) => n !== i + 1);
            })))] : []
          ]),
          h("p", { class: "notice" }, (task.scheduleType === "once" ? date.year + "\u5E74" + date.month + "\u6708" + date.day + "\u65E5" : task.scheduleType === "weekly" ? "\u6BCF\u5468 " + task.weekdays.map((n) => weekdays[n - 1]).join("\u3001") : "\u6BCF\u5929") + " " + task.time + "\uFF08" + task.timezone + "\uFF09\u8BFB\u53D6\u4F1A\u8BDD\uFF0C\u518D\u7531\u6240\u9009\u6A21\u578B\u51B3\u5B9A\u662F\u5426\u53D1\u9001\u3002"),
          h("h3", "4. \u5224\u65AD\u4E0E\u5199\u4F5C\u8981\u6C42"),
          area("\u5224\u65AD\u4E0E\u5199\u4F5C\u8981\u6C42", task.prompt, (v) => task.prompt = v),
          h("p", { class: "muted" }, "\u8BF4\u660E\u4EC0\u4E48\u60C5\u51B5\u4E0B\u503C\u5F97\u53D1\u90AE\u4EF6\u3001\u9700\u8981\u5305\u542B\u4EC0\u4E48\u5185\u5BB9\uFF1B\u65E0\u5FC5\u8981\u65F6\u6A21\u578B\u4F1A\u8DF3\u8FC7\u3002\u9ED8\u8BA4\u6CBF\u7528\u4F1A\u8BDD\u9884\u8BBE\u3002"),
          ...templateFields.length ? [h("h3", "\u6A21\u677F\u53D8\u91CF"), h("div", { class: "grid" }, templateFields.map(([name, field]) => h("div", { class: "variable-card" }, [
            h("strong", name + (field.required ? " \xB7 \u5FC5\u586B" : " \xB7 \u53EF\u9009")),
            input("\u53D8\u91CF\u503C " + name, vars()[name] ?? "", (v) => {
              variableText.value = JSON.stringify({ ...vars(), [name]: v }, null, 2);
            }, "text", { placeholder: field.default ? "\u9ED8\u8BA4\uFF1A" + field.default : "\u8BF7\u8F93\u5165\u53D8\u91CF\u503C" }),
            button("\u63D2\u5165 {{" + name + "}}", () => insertVariable("\u5224\u65AD\u4E0E\u5199\u4F5C\u8981\u6C42", task.prompt, (v) => task.prompt = v, name), "chip")
          ])))] : [],
          h("details", [h("summary", "\u9AD8\u7EA7\u8BBE\u7F6E\uFF08\u901A\u5E38\u65E0\u9700\u4FEE\u6539\uFF09"), h("div", { class: "grid" }, [
            input("\u4EFB\u52A1 ID\uFF08\u81EA\u52A8\u751F\u6210\uFF09", task.id, (v) => task.id = v, "text", { disabled: taskExisting.value, placeholder: "\u7559\u7A7A\u81EA\u52A8\u751F\u6210" }),
            input("\u624B\u52A8\u586B\u5199\u4F1A\u8BDD ID", task.conversationId, (v) => task.conversationId = v),
            select("\u9884\u8BBE\u8986\u76D6", task.preset, presets, (v) => task.preset = v),
            input("\u81EA\u5B9A\u4E49 IANA \u65F6\u533A", task.timezone, (v) => task.timezone = v),
            input("\u624B\u52A8\u586B\u5199\u6A21\u578B ID", task.model, (v) => {
              task.model = v;
              task.useDefaultModel = false;
            }),
            input("\u5386\u53F2\u6D88\u606F\u4E0A\u9650", task.historyLimit, (v) => task.historyLimit = Number(v), "number", { min: 1, max: 200 }),
            input("\u53D1\u9001\u51B7\u5374\u5206\u949F", task.cooldownMinutes, (v) => task.cooldownMinutes = Number(v), "number", { min: 1, max: 10080 }),
            select("\u4E0A\u4E0B\u6587\u8303\u56F4", task.contextMode, [["recent", "\u5F53\u524D\u5206\u652F\u6700\u8FD1\u6D88\u606F"], ["since-last-send", "\u81EA\u4E0A\u6B21\u53D1\u4FE1\u540E\u7684\u65B0\u589E\u6D88\u606F"]], (v) => task.contextMode = v),
            input("\u4E0A\u4E0B\u6587\u6700\u5927\u5E74\u9F84\uFF08\u5C0F\u65F6\uFF0C0 \u4E0D\u9650\u5236\uFF09", task.contextMaxAgeHours, (v) => task.contextMaxAgeHours = Number(v), "number", { min: 0, max: 8760 }),
            input("\u6700\u4F4E\u65B0\u589E\u6D88\u606F\u6570\uFF080 \u4E0D\u9650\u5236\uFF09", task.minNewMessages, (v) => task.minNewMessages = Number(v), "number", { min: 0, max: 100 }),
            select("\u4E0A\u4E0B\u6587\u8D85\u9884\u7B97\u65F6", task.contextOverflow, [["reject", "\u505C\u6B62\u5E76\u62A5\u544A\u8D85\u9650"], ["trim-oldest", "\u79FB\u9664\u6700\u65E7\u6D88\u606F"]], (v) => task.contextOverflow = v),
            check("\u5141\u8BB8\u5BF9\u660E\u786E\u6682\u65F6\u6027\u5931\u8D25\u81EA\u52A8\u91CD\u8BD5", task.retryOnFailure, (v) => task.retryOnFailure = v),
            area("\u5176\u4ED6\u9884\u8BBE\u53D8\u91CF\uFF08JSON \u5BF9\u8C61\uFF09", variableText.value, (v) => variableText.value = v)
          ])]),
          h("div", { class: "bar" }, [check("\u4FDD\u5B58\u540E\u542F\u7528\u5B9A\u65F6\u4EFB\u52A1", task.enabled, (v) => task.enabled = v), button("\u4FDD\u5B58\u4EFB\u52A1", saveTask, "primary")]),
          h("p", { class: "muted" }, "\u65B0\u4EFB\u52A1\u9ED8\u8BA4\u505C\u7528\u3002\u4FDD\u5B58\u540E\u53EF\u7528\u201C\u8BD5\u5224\u65AD\u201D\u68C0\u67E5\u7ED3\u679C\uFF0C\u4E0D\u4F1A\u81EA\u52A8\u53D1\u9001\u90AE\u4EF6\u3002")
        ])
      ];
    }
    function templatePanel() {
      return [
        h("div", { class: "bar" }, [button("\uFF0B \u65B0\u5EFA\u6A21\u677F", () => {
          editTemplate();
          focusEditor(templateEditor);
        }, "primary")]),
        table(["\u6A21\u677F", "\u7248\u672C", "\u64CD\u4F5C"], data.value.templates.map((t) => [
          t.name + " / " + t.id,
          "v" + t.version,
          h("div", { class: "bar" }, [...!["briefing", "notice", "plain"].includes(t.id) ? [button("\u7F16\u8F91", () => {
            editTemplate(t);
            focusEditor(templateEditor);
          })] : [], button("\u590D\u5236", () => {
            editTemplate(t, true);
            focusEditor(templateEditor);
          })])
        ])),
        h("h3", { class: "editor-heading", ref: templateEditor, tabindex: -1 }, templateExisting.value ? "\u7F16\u8F91\u6A21\u677F" : "\u65B0\u5EFA\u6A21\u677F"),
        h("div", { class: "card grid" }, [
          input("\u6A21\u677F ID", template.id, (v) => template.id = v, "text", { disabled: templateExisting.value }),
          input("\u6A21\u677F\u540D\u79F0", template.name, (v) => template.name = v),
          input("\u5F3A\u8C03\u8272", template.layout.accent, (v) => template.layout.accent = v, "color"),
          input("\u80CC\u666F\u8272", template.layout.background, (v) => template.layout.background = v, "color"),
          input("\u6587\u5B57\u989C\u8272", template.layout.textColor, (v) => template.layout.textColor = v, "color"),
          input("\u5185\u5BB9\u5BBD\u5EA6", template.layout.width, (v) => template.layout.width = Number(v), "number", { min: 320, max: 800 }),
          check("\u663E\u793A\u90AE\u4EF6\u6807\u9898", template.layout.heading, (v) => template.layout.heading = v),
          area("\u5199\u4F5C\u63D0\u793A\u8BCD\uFF08\u53D8\u91CF\u4F7F\u7528 {{name}}\uFF09", template.prompt, (v) => template.prompt = v),
          area("\u90AE\u4EF6\u9875\u811A\uFF08\u53D8\u91CF\u4F7F\u7528 {{name}}\uFF09", template.layout.footer, (v) => template.layout.footer = v),
          h("div", { class: "wide" }, [
            h("h3", "\u53D8\u91CF\u5361\u7247"),
            h("p", { class: "muted" }, "\u6BCF\u5F20\u5361\u7247\u58F0\u660E\u4E00\u4E2A\u53D8\u91CF\u3002\u70B9\u51FB\u53D8\u91CF\u6309\u94AE\u53EF\u63D2\u5165\u63D0\u793A\u8BCD\u6216\u9875\u811A\uFF1B\u9884\u89C8\u503C\u53EA\u7528\u4E8E\u6392\u7248\u9884\u89C8\u3002"),
            button("\u6DFB\u52A0\u53D8\u91CF", () => {
              variableRows.value.push({ name: "", required: false, default: "" });
            }),
            h("div", { class: "grid" }, variableRows.value.map((row, i) => h("div", { class: "variable-card" }, [
              input("\u53D8\u91CF\u540D\u79F0 " + (i + 1), row.name, (v) => row.name = v, "text", { placeholder: "\u4F8B\u5982 recipient_name" }),
              check("\u5FC5\u586B\u53D8\u91CF " + (i + 1), row.required, (v) => row.required = v),
              input("\u9ED8\u8BA4\u503C " + (i + 1), row.default, (v) => row.default = v),
              input("\u9884\u89C8\u503C " + (i + 1), previewValues.value[row.name] ?? "", (v) => previewValues.value[row.name] = v),
              h("div", { class: "bar" }, [
                button("\u63D2\u5165\u63D0\u793A\u8BCD {{" + (row.name || "\u53D8\u91CF\u540D") + "}}", () => insertVariable("\u5199\u4F5C\u63D0\u793A\u8BCD\uFF08\u53D8\u91CF\u4F7F\u7528 {{name}}\uFF09", template.prompt, (v) => template.prompt = v, row.name), "chip"),
                button("\u63D2\u5165\u9875\u811A", () => insertVariable("\u90AE\u4EF6\u9875\u811A\uFF08\u53D8\u91CF\u4F7F\u7528 {{name}}\uFF09", template.layout.footer, (v) => template.layout.footer = v, row.name), "chip"),
                button("\u79FB\u9664\u53D8\u91CF " + (i + 1), () => {
                  variableRows.value.splice(i, 1);
                }, "danger")
              ])
            ])))
          ]),
          h("div", { class: "bar wide" }, [
            button("\u4FDD\u5B58\u65B0\u7248\u672C", saveTemplate, "primary"),
            button("\u9884\u89C8\u6392\u7248", async () => {
              const value = { ...clone(template), fields: variableDefinitions(variableRows.value) };
              preview.value = await send("mail-admin/template-preview", { template: value, mail: { to: ["preview@example.com"], subject: "\u56FE\u6587\u90AE\u4EF6\u6392\u7248\u9884\u89C8", paragraphs: ["\u8FD9\u91CC\u5C55\u793A\u7B2C\u4E00\u6BB5\u6B63\u6587\u3002", "\u6240\u6709\u53D8\u91CF\u548C\u6B63\u6587\u90FD\u7ECF\u8FC7 HTML \u8F6C\u4E49\u3002"], images: [], templateId: template.id, variables: previewValues.value } });
              previewDraft.value = "";
            })
          ])
        ])
      ];
    }
    async function fetchRecords() {
      recordData.value = await send("mail-admin/records", { kind: recordKind.value, page: recordPage.value, status: recordStatus.value });
    }
    function runsPanel() {
      return [
        h("h3", "\u5386\u53F2\u67E5\u8BE2"),
        h("div", { class: "card" }, [
          h("div", { class: "grid" }, [
            select("\u8BB0\u5F55\u7C7B\u578B", recordKind.value, [["run", "\u6A21\u578B\u5224\u65AD"], ["delivery", "\u90AE\u4EF6\u6295\u9012"]], (v) => {
              recordKind.value = v;
              recordPage.value = 1;
            }),
            select("\u72B6\u6001\u7B5B\u9009", recordStatus.value, [["", "\u5168\u90E8"], ...["accepted", "partial", "failed", "unknown", "error", "skipped", "preview", "interrupted", "cooldown"].map((s) => [s, s])], (v) => {
              recordStatus.value = v;
              recordPage.value = 1;
            })
          ]),
          h("div", { class: "bar" }, [
            button("\u67E5\u8BE2", fetchRecords),
            button("\u4E0A\u4E00\u9875", async () => {
              recordPage.value = Math.max(1, recordPage.value - 1);
              await fetchRecords();
            }),
            h("span", "\u7B2C " + recordPage.value + " \u9875 / \u5171 " + (recordData.value?.total ?? "\u2014") + " \u6761"),
            button("\u4E0B\u4E00\u9875", async () => {
              if (recordData.value && recordPage.value * 20 < recordData.value.total) recordPage.value++;
              await fetchRecords();
            })
          ]),
          recordData.value ? table(["\u65F6\u95F4", "\u8BB0\u5F55", "\u72B6\u6001", "\u8BF4\u660E"], recordData.value.items.map((r) => [dateText(r.at ?? r.createdAt), r.id, r.status, r.redacted ? "\u6B63\u6587\u5DF2\u6309\u4FDD\u7559\u671F\u6E05\u7406" : r.decision?.reason ?? r.detail ?? r.errorCode ?? "\u2014"])) : null
        ]),
        h("h3", "\u6700\u8FD1\u5224\u65AD"),
        table(["\u65F6\u95F4", "\u4EFB\u52A1 / \u72B6\u6001", "\u7406\u7531\u6216\u6545\u969C", "\u64CD\u4F5C"], data.value.runs.map((r) => [
          dateText(r.at),
          r.taskId + " / " + r.status,
          r.redacted ? "\u6B63\u6587\u5DF2\u6E05\u7406" : r.decision?.reason ?? r.detail ?? r.errorCode ?? "\u2014",
          r.draftId && !r.redacted ? button("\u9884\u89C8\u8349\u7A3F", () => loadPreview(r.draftId)) : "\u2014"
        ])),
        h("h3", "\u6700\u8FD1\u6295\u9012"),
        table(["\u65F6\u95F4", "\u8BB0\u5F55 ID", "\u72B6\u6001", "\u64CD\u4F5C"], data.value.deliveries.map((d) => [
          dateText(d.createdAt),
          d.id,
          d.status,
          d.canRetry ? button("\u5B89\u6392\u91CD\u8BD5", async () => {
            if (!window.confirm("\u53EA\u91CD\u8BD5\u786E\u5B9A\u672A\u6295\u9012\u7684\u6536\u4EF6\u4EBA\uFF0C\u590D\u7528\u539F\u90AE\u4EF6\u5185\u5BB9\u3002\u662F\u5426\u52A0\u5165\u91CD\u8BD5\u961F\u5217\uFF1F")) return;
            const result = await send("mail-admin/retry-create", { id: d.id });
            notice.value = JSON.stringify(result, null, 2);
            await refresh();
          }) : d.redacted ? "\u5185\u5BB9\u5DF2\u6E05\u7406" : "\u2014"
        ])),
        h("h3", "\u91CD\u8BD5\u961F\u5217"),
        table(["\u8BA1\u5212\u65F6\u95F4", "\u539F\u8BB0\u5F55", "\u6B21\u6570 / \u72B6\u6001", "\u64CD\u4F5C"], (data.value.retryJobs ?? []).map((j) => [
          dateText(j.dueAt),
          j.sourceId,
          j.attempt + " / " + j.status + (j.outcome ? " / " + j.outcome : ""),
          j.status === "scheduled" ? button("\u53D6\u6D88\u91CD\u8BD5", async () => {
            await send("mail-admin/retry-cancel", { id: j.id });
            await refresh();
          }) : "\u2014"
        ]))
      ];
    }
    function maintenancePanel() {
      const policy = data.value.policy ?? {};
      return [
        h("h3", "\u8FD0\u884C\u7B56\u7565"),
        h("div", { class: "card" }, [
          h("p", "\u81EA\u52A8\u91CD\u8BD5\uFF1A" + (policy.autoRetryEnabled ? "\u5F00\u542F" : "\u5173\u95ED") + "\uFF1B\u6700\u591A " + (policy.maxRetryAttempts ?? 2) + " \u6B21\uFF1B\u57FA\u7840\u9000\u907F " + (policy.retryDelayMinutes ?? 5) + " \u5206\u949F\u3002"),
          h("p", "\u81EA\u52A8\u6E05\u7406\uFF1A" + (policy.cleanupEnabled ? "\u5F00\u542F" : "\u5173\u95ED") + "\uFF1B\u5386\u53F2\u5185\u5BB9\u4FDD\u7559 " + (policy.retentionDays ?? 30) + " \u5929\uFF1B\u6BCF\u5C0F\u65F6\u5224\u65AD\u4E0A\u9650 " + (policy.maxDecisionsPerHour ?? 60) + " \u6B21\u3002"),
          h("p", { class: "muted" }, "\u7B56\u7565\u5728\u63D2\u4EF6\u914D\u7F6E\u4E2D\u4FEE\u6539\u3002\u672A\u77E5\u6295\u9012\u7ED3\u679C\u4E0D\u91CD\u8BD5\uFF1B\u5DF2\u63A5\u53D7\u7684\u6536\u4EF6\u4EBA\u4E0D\u4F1A\u52A0\u5165\u90E8\u5206\u5931\u8D25\u91CD\u8BD5\u3002"),
          data.value.invalidTaskIds?.length ? h("p", { class: "error" }, "\u5B58\u5728\u65E0\u6548\u4EFB\u52A1\u8BB0\u5F55\uFF1A" + data.value.invalidTaskIds.join(", ")) : null
        ]),
        h("h3", "\u4FDD\u7559\u671F\u6E05\u7406"),
        h("div", { class: "card" }, [
          h("p", "\u7CBE\u7B80\u8FC7\u671F\u90AE\u4EF6\u6B63\u6587\u4E0E\u5224\u65AD\u8BE6\u60C5\u3001\u4F7F\u8FC7\u671F\u8349\u7A3F\u5931\u6548\uFF0C\u4FDD\u7559\u6295\u9012\u53CA\u8C03\u5EA6\u7684\u9632\u91CD\u590D\u6807\u8BC6\u3002\u672A\u56FA\u5B9A\u4E14\u65E0\u5F15\u7528\u7684\u65E7\u56FE\u7247\u79FB\u5165\u53EF\u6062\u590D\u56DE\u6536\u533A\u3002"),
          button("\u9884\u89C8\u6E05\u7406\u8303\u56F4", async () => {
            cleanupPlan.value = await send("mail-admin/cleanup-preview");
            notice.value = "\u4EC5\u751F\u6210\u9884\u89C8\uFF0C\u5C1A\u672A\u6E05\u7406\u4EFB\u4F55\u5185\u5BB9\u3002";
          }),
          cleanupPlan.value ? h("div", [
            h("pre", JSON.stringify({ counts: cleanupPlan.value.counts, retentionDays: cleanupPlan.value.days, items: cleanupPlan.value.items }, null, 2)),
            button("\u6267\u884C\u6B64\u6E05\u7406\u8BA1\u5212", async () => {
              if (!window.confirm("\u786E\u8BA4\u6E05\u7406\uFF1F\u65E7\u6B63\u6587\u548C\u8FC7\u671F\u8349\u7A3F\u5185\u5BB9\u5C06\u4E0D\u53EF\u6062\u590D\uFF1B\u9632\u91CD\u590D\u6807\u8BC6\u4FDD\u7559\uFF0C\u56FE\u7247\u8FDB\u5165\u53EF\u6062\u590D\u56DE\u6536\u533A\u3002")) return;
              notice.value = JSON.stringify(await send("mail-admin/cleanup-apply", { planId: cleanupPlan.value.planId, confirm: true }), null, 2);
              cleanupPlan.value = null;
              await refresh();
            }, "danger")
          ]) : null
        ]),
        h("h3", "\u53EF\u7528\u56FE\u7247"),
        table(["assetId", "\u683C\u5F0F / \u5927\u5C0F", "\u4FDD\u7559\u72B6\u6001", "\u64CD\u4F5C"], data.value.assets.map((a) => [
          a.id,
          a.mime + " / " + Math.ceil(a.bytes / 1024) + " KiB",
          a.pinned === false ? "\u53EF\u6309\u4FDD\u7559\u671F\u56DE\u6536" : "\u56FA\u5B9A\u4FDD\u7559",
          button(a.pinned === false ? "\u56FA\u5B9A\u4FDD\u7559" : "\u53D6\u6D88\u56FA\u5B9A", async () => {
            await send("mail-admin/asset-pin", { id: a.id, pinned: a.pinned === false });
            await refresh();
          })
        ])),
        h("h3", "\u56FE\u7247\u56DE\u6536\u533A"),
        table(["assetId", "\u8FDB\u5165\u56DE\u6536\u533A\u65F6\u95F4", "\u64CD\u4F5C"], (data.value.trashedAssets ?? []).map((a) => [
          a.id,
          dateText(a.trashedAt),
          button("\u6062\u590D\u5E76\u56FA\u5B9A", async () => {
            await send("mail-admin/asset-restore", { id: a.id });
            await refresh();
          })
        ]))
      ];
    }
    return () => h(resolveComponent("k-layout"), null, {
      default: () => h("div", { class: "mail-viewport", ref: viewport, tabindex: 0, role: "region", "aria-label": "\u90AE\u4EF6\u4EFB\u52A1\u5185\u5BB9" }, [h("div", { class: "mail-admin" }, [
        h("style", css),
        h("header", { class: "hero" }, [
          h("div", { class: "hero-title" }, [h("div", { class: "hero-icon" }, [h(MailIcon)]), h("div", [h("h2", "\u90AE\u4EF6\u4EFB\u52A1"), h("p", { class: "muted" }, "\u628A\u503C\u5F97\u5173\u6CE8\u7684\u6D88\u606F\uFF0C\u5728\u5408\u9002\u7684\u65F6\u95F4\u9001\u8FBE\u3002")])]),
          h("span", { class: "version" }, "v" + (data.value.version ?? "\u2026"))
        ]),
        h("div", { class: "stats" }, [
          h("div", { class: "stat" }, [h("div", [h("div", { class: "stat-label" }, "\u90AE\u4EF6\u4EFB\u52A1"), h("div", { class: "stat-value" }, data.value.tasks.length + " \u4E2A \xB7 " + data.value.tasks.filter((r) => r.task.enabled).length + " \u4E2A\u542F\u7528")]), h("svg", { class: "stat-symbol", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", "stroke-width": 1.6, "aria-hidden": "true" }, [h("rect", { x: 4, y: 4, width: 16, height: 17, rx: 3 }), h("path", { d: "M8 2v4m8-4v4M4 10h16m-12 4h3m-3 3h7" })])]),
          h("div", { class: "stat" }, [h("div", [h("div", { class: "stat-label" }, "\u53D1\u4FE1\u72B6\u6001"), h("div", { class: "stat-value" }, data.value.paused ? "\u672C\u6B21\u5DF2\u6682\u505C" : data.value.enabled ? "\u5141\u8BB8\u53D1\u4FE1" : "\u5168\u5C40\u5DF2\u5173\u95ED")]), h(MailIcon, { class: "stat-symbol" })]),
          h("div", { class: "stat" }, [h("div", [h("div", { class: "stat-label" }, "\u90AE\u4EF6\u9ED8\u8BA4\u6A21\u578B"), h("div", { class: "stat-value", style: "font-size:14px" }, data.value.modelSettings?.defaultModel || "\u8DDF\u968F\u4EFB\u52A1\u8BBE\u7F6E")])])
        ]),
        h("p", { class: "recipient-info" }, "\u5141\u8BB8\u6536\u4EF6\u4EBA\uFF1A" + (data.value.allowedRecipients.join("\u3001") || "\u5C1A\u672A\u914D\u7F6E") + " \xB7 \u6BCF\u6B21\u7531\u4E00\u4E2A\u6A21\u578B\u6839\u636E\u4F1A\u8BDD\u4E0A\u4E0B\u6587\u5224\u65AD\u662F\u5426\u53D1\u9001"),
        h("nav", { class: "navigation", "aria-label": "\u90AE\u4EF6\u7BA1\u7406\u5BFC\u822A" }, [
          h("div", { class: "tabs" }, [["tasks", "\u4EFB\u52A1"], ["models", "\u6A21\u578B\u8BBE\u7F6E"], ["workflow", "\u5DE5\u4F5C\u6D41"], ["templates", "\u6A21\u677F"], ["runs", "\u6267\u884C\u8BB0\u5F55"], ["maintenance", "\u8FD0\u884C\u7EF4\u62A4"]].map(([id, label]) => h("button", { type: "button", class: ["tab", tab.value === id ? "active" : ""], "aria-pressed": tab.value === id, disabled: busy.value, onClick: () => switchTab(id) }, label))),
          h("div", { class: "nav-tools" }, [button("\u5237\u65B0", refresh), button("\u56DE\u5230\u9876\u90E8", () => viewport.value?.scrollTo({ top: 0 })), button(data.value.paused ? "\u6062\u590D\u53D1\u9001" : "\u6682\u505C\u53D1\u9001", async () => {
            await send(data.value.paused ? "mail-admin/resume" : "mail-admin/pause");
            await refresh();
          }, "danger", true)])
        ]),
        notice.value ? h("pre", { class: ["notice", error.value ? "error" : ""] }, notice.value) : null,
        resultDetails.value?.draftId ? button("\u67E5\u770B\u90AE\u4EF6\u9884\u89C8", () => switchTab("templates")) : null,
        resultDetails.value ? h("details", { class: "card" }, [h("summary", "\u67E5\u770B\u8BCA\u65AD\u8BE6\u60C5"), h("pre", JSON.stringify(resultDetails.value, null, 2))]) : null,
        ...tab.value === "tasks" ? taskPanel() : tab.value === "models" ? modelPanel() : tab.value === "workflow" ? workflowPanel() : tab.value === "templates" ? templatePanel() : tab.value === "maintenance" ? maintenancePanel() : runsPanel(),
        preview.value && tab.value === "templates" ? h("div", { class: "card" }, [
          h("h3", "\u90AE\u4EF6\u9884\u89C8"),
          preview.value.mail ? h("p", "\u6536\u4EF6\u4EBA\uFF1A" + preview.value.mail.to.join(", ") + " \xB7 \u6A21\u677F\u7248\u672C\uFF1A" + preview.value.templateVersion) : null,
          h("iframe", { title: "\u90AE\u4EF6\u5185\u5BB9\u9884\u89C8", sandbox: "", srcdoc: preview.value.html }),
          h("pre", preview.value.text),
          previewDraft.value ? button("\u53D1\u9001\u6B64\u8349\u7A3F", async () => {
            if (!window.confirm("\u786E\u8BA4\u53D1\u9001\u5230 " + preview.value.mail.to.join(", ") + "\uFF1F")) return;
            const result = await send("mail-admin/send", { id: previewDraft.value });
            notice.value = JSON.stringify(result, null, 2);
            await refresh();
          }, "primary") : null
        ]) : null,
        h("p", { class: "muted footer" }, "\u8BD5\u5224\u65AD\uFF0F\u8BD5\u8FD0\u884C\u5747\u4E0D\u81EA\u52A8\u53D1\u4FE1\uFF1B\u5DE5\u5177\u6A21\u5F0F\u4F1A\u8C03\u7528\u5916\u90E8\u5DE5\u5177\u5E76\u53EF\u80FD\u4EA7\u751F\u7ED8\u56FE\u8D39\u7528\u3002\u9519\u8FC7\u8BA1\u5212\u5206\u949F\u4E0D\u8865\u53D1\u3002\u542F\u505C\u603B\u5F00\u5173\u548C\u90AE\u7BB1\u8D26\u53F7\u8BF7\u5728\u63D2\u4EF6\u914D\u7F6E\u4E2D\u8BBE\u7F6E\u3002")
      ])])
    });
  }
});
var index_default = (ctx) => {
  icons.register("chatluna-mail:envelope", MailIcon);
  ctx.page({ name: "\u90AE\u4EF6\u4EFB\u52A1", path: "/chatluna-mail", icon: "chatluna-mail:envelope", authority: 4, order: 690, component: MailPage });
};
export {
  MailPage,
  index_default as default,
  freshTask,
  freshTemplate
};
//# sourceMappingURL=index.js.map