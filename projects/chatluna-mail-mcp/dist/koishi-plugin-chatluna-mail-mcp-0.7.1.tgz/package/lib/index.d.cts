import { Context, Schema } from 'koishi';

interface Config$1 {
    endpoint: string;
    token: string;
    enabled: boolean;
    allowAgentSend: boolean;
    allowedRecipients: string[];
    smtpHost: string;
    smtpPort: number;
    smtpSecure: boolean;
    smtpUser: string;
    smtpPassword: string;
    from: string;
    maxPerDay: number;
    modelTimeoutMs: number;
    maxContextChars: number;
    allowAgentManage?: boolean;
    autoRetryEnabled?: boolean;
    maxRetryAttempts?: number;
    retryDelayMinutes?: number;
    cleanupEnabled?: boolean;
    retentionDays?: number;
    maxDecisionsPerHour?: number;
}
interface Entry {
    id: string;
    kind: string;
    status: string;
    payload: string;
    hash: string;
    createdAt: Date;
    updatedAt: Date;
}
declare module 'koishi' {
    interface Tables {
        chatluna_mail: Entry;
    }
}

declare function registerModels(ctx: Context): void;

declare const name = "chatluna-mail-mcp";
declare const inject: {
    required: string[];
    optional: string[];
};
declare const Config: Schema<Config$1>;
declare function apply(ctx: Context, config: Config$1): void;

export { Config, apply, inject, name, registerModels };
